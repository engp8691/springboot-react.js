import React from 'react';
import { makeStyles, withStyles, styled } from '@material-ui/core/styles';
import MenuItem from '@material-ui/core/MenuItem';
import FormHelperText from '@material-ui/core/FormHelperText';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
// import styled from "styled-components";
import Button from "@material-ui/core/Button";

const useStyles1 = makeStyles(theme => ({
    root: {
        color: 'blue',
        borderColor: 'green',
        backgroundColor: 'red',
    },
    icon: {
        fill: 'red',
    },
    formControl: {
        margin: theme.spacing(1),
        minWidth: 120,
    },
    selectEmpty: {
        marginTop: theme.spacing(2),
    },
}));

export const SimpleSelect = function () {
    const classes = useStyles1();
    console.log(classes);

    const [age, setAge] = React.useState('');

    React.useEffect(() => {
    }, []);

    const handleChange = event => {
        setAge(event.target.value);
    };

    return (
        <div>
            <FormControl className={classes.formControl}>
                <Select value={age} onChange={handleChange} displayEmpty classes={{
                    root: classes.root,
                    icon: classes.icon
                }}>
                    <MenuItem value="" disabled>
                        Placeholder
          </MenuItem>
                    <MenuItem value={10}>Ten</MenuItem>
                    <MenuItem value={20}>Twenty</MenuItem>
                    <MenuItem value={30}>Thirty</MenuItem>
                </Select>
            </FormControl>
        </div>
    );
}

const StyledButton = styled(Button)({
    background: 'linear-gradient(45deg, #fe6b8b 30%, #ff8e53 90%)',
    borderRadius: '3px',
    border: 0,
    color: 'white',
    height: '48px',
    padding: '0 30px',
    boxShadow: '0 3px 5px 2px rgba(255, 105, 135, 0.3)'
})

export const StyledComponentsButton = function () {
    return (
        <div>
            <Button>Material-UI</Button>
            <StyledButton>Styled Components</StyledButton>
        </div>
    );
}


const useStyles2 = makeStyles({
    anyname: {
        background: 'linear-gradient(45deg, #FE6B8B 30%, #FF8E53 90%)',
        border: 0,
        borderRadius: 3,
        boxShadow: '0 3px 5px 2px rgba(255, 105, 135, .3)',
        color: 'white',
        height: 48,
        padding: '0 30px',
    },
});

export const HookButton = function () {
    const classes = useStyles2();
    return <Button className={classes.anyname}>Hook</Button>;
}

const styles3 = {
    root: {
      background: 'linear-gradient(45deg, #FE6B8B 30%, #FF8E53 90%)',
      border: 0,
      borderRadius: 3,
      boxShadow: '0 3px 5px 2px rgba(255, 105, 135, .3)',
      color: 'white',
      height: 48,
      padding: '0 30px',
    },
  };
  
  function HOC(props) {
    const { classes } = props;
    return <Button className={classes.root}>Higher-order component</Button>;
  }
  
  export const HigherOrderComponent = withStyles(styles3)(HOC);
  