import React from 'react';

import Loading from '../components/Loading';
import Error from '../components/Error';
import Employees from '../components/Employees';
import EmployForm from './EmployeeForm';

import { useAsync } from "react-async"
import { fetchEmployees, fetchEmployeeByID, deleteEmployee } from '../api/Services';

import "../App.css";
import { callbackify } from 'util';

const EmployeeContainer = () => {
    // const { data, error, isPending, run } = useAsync({ promiseFn: fetchEmployees });

    const { data, error, isPending, run } = useAsync({ deferFn: fetchEmployees });

    

    React.useEffect(() => {
        setTimeout(()=>{
            run();
        }, 0);

        // run();
    }, []);

    console.log(data, error, isPending, run);

    // const content = isPending? <Loading /> : error? <Error /> : <Employees data={data} />
    // content;

    return (
        <>
            <div style={{
                position: "absolute",
                top: 20,
                left: (100% - 200),
                marginRight: "-50%"}}>
                <EmployForm run={run} />
            </div>
            <div>
                {
                    isPending ? <Loading /> : error ? <Error /> : <Employees data={data} deleteEmployee={deleteEmployee} />
                }
            </div>
        </>
    );
}

export default EmployeeContainer;