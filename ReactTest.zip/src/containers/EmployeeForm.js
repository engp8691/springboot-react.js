import React from 'react';

import { TextField, Paper, Button } from '@material-ui/core';
import { addEmployee } from '../api/Services';
import { useAsync } from "react-async"
import Loading from '../components/Loading';

import axios from 'axios';

const EmployForm = (props) => {
    const [firstName, setFirstName] = React.useState('');
    const [lastName, setLastName] = React.useState('');
    const [email, setEmail] = React.useState('');
    const [submitting, setSubmitting] = React.useState(false);
    const { data, error, isPending, run } = useAsync({ deferFn: addEmployee });

    const handleSubmit = (e) => {
        e.preventDefault();

        // props.run();

        let employeeData = {};
        employeeData.firstName = firstName;
        employeeData.lastName = lastName;
        employeeData.email = email;

        var bodyFormData = new FormData();
        bodyFormData.set('firstName', firstName);
        bodyFormData.set('lastName', lastName);
        bodyFormData.set('email', email);

        console.log(employeeData);
        run(employeeData);
    }

    const handleChange = (setFunction) => {
        return (e) => {
            try {
                setFunction(e.target.value);
            } catch (e) {
                console.log(e);
            }
        }
    }

    return (
        isPending ? <Loading /> : (
            <form onSubmit={handleSubmit}>
                <Paper style={{
                    padding: 16,
                    width: 400
                }}>
                    <TextField
                        id="firstName"
                        label="First Name"
                        value={firstName}
                        onChange={handleChange(setFirstName)}
                        margin="normal"
                        fullWidth
                    />

                    <TextField
                        id="lastName"
                        label="Last Name"
                        value={lastName}
                        onChange={handleChange(setLastName)}
                        margin="normal"
                        fullWidth
                    />

                    <TextField
                        id="email"
                        label="Email"
                        value={email}
                        onChange={handleChange(setEmail)}
                        margin="normal"
                        fullWidth
                    />

                    <Button variant="contained" color="primary" type="submit" disabled={submitting}>Submit</Button>
                </Paper>
            </form>
        )
    )
}

export default EmployForm;