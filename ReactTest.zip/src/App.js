import React from 'react';
import {SimpleSelect, StyledComponentsButton, HookButton, HigherOrderComponent} from './MySelect';

import EmployeeContainer from './containers/EmployeeContainer';

import People from './components/People';

import './App.css';

function App() {
  return (
    <div className="App">
      {/* <SimpleSelect />
      <StyledComponentsButton />
      <HookButton />
      <HigherOrderComponent /> */}
      
      <div>
        <EmployeeContainer />
      </div>
      
      {/* <div>
        <People />
      </div>       */}
    </div>
  );
}

export default App;
