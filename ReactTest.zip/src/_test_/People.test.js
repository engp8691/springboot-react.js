import React from 'react';
import { render, cleanup, waitForElement, fireEvent, act } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect'

import People from '../Components/People';

afterEach(cleanup)
jest.setTimeout(5000);

test('Test the Person Object', async (done) => {
    const tree = (<People />);
    const { getAllByText, getByText, queryByText, container, getByTestId} = render(tree);

    // Test that Roger Anderson is really there
    const name = await waitForElement(() => getByText(/Roger/i));
    expect(name).toHaveTextContent(/Roger Anderson/i);

    // Test the number of people there is 4, before dismissing Roger Anderson
    const prev_names = await waitForElement(() => getAllByText(/Name:/i));
    expect(prev_names.length).toBe(4); // There 4 people

    // Dismiss Roger Anderson
    const btn = await waitForElement(() => getByTestId(/Roger Anderson/));
    expect(btn).toHaveTextContent(/Delete/i);
    fireEvent.click(btn);

     // Test the number of people there is 3, before dismissing Roger Anderson
     const next_names = await waitForElement(() => getAllByText(/Name:/i));
     expect(next_names.length).toBe(3); // It becomes to 3

     // Assert Roger is not there in the names
     expect(queryByText(/Roger/i)).toBeNull();

     // Assert Trum is there
     expect(queryByText(/Trump/i)).not.toBeNull();

     // Assert Obama is there
     expect(queryByText(/Obama/i)).not.toBeNull();

    setTimeout(() => {
        done();
    }, 1);

    expect(container).toBeVisible();
})
