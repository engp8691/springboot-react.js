import React from 'react';
import { render, cleanup, waitForElement, fireEvent, act } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';

import Person from '../Components/Person';

afterEach(cleanup)
jest.setTimeout(5000);

test('Test the Person Object', async (done) => {
    const dismissPeople = jest.fn().mockImplementation(() => "Deleted");

    const tree = (<Person name="Yonglin Li" age="30" dismissPeople={dismissPeople} />);
    const { getByText, container } = render(tree);

    const name = await waitForElement(() => getByText(/Yonglin/));
    expect(name).toHaveTextContent(/Yonglin Li/i);

    // Check that the mock function is not yet called
    expect(dismissPeople.mock.calls.length).toBe(0); // It is 0

    const btn = await waitForElement(() => getByText(/Delete/));
    expect(btn).toHaveTextContent(/Delete/i);
    fireEvent.click(btn);

    // Assert that the mock function is call once when the delete button is clicked
    expect(dismissPeople.mock.calls.length).toBe(1); // It called 1 time

    setTimeout(() => {
        done();
    }, 1);

    expect(container).toBeVisible();
})
