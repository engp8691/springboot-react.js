import React from 'react';
import { useAsync } from "react-async"
import Loading from './Loading';

const Employee = (props) => {
    const { data, error, isPending, run } = useAsync({ deferFn: props.deleteEmployee });

    const deleteByID = () => {
        run(props.id);
    }

    console.log(isPending, data);

    if (isPending) {
        return (<Loading />)
    } else {
        if (data !== undefined) {
            return null;
        } else {
            return (
                <div>
                    <span>{props.firstName + props.lastName}</span>
                    <span>{props.id}</span>
                    <button onClick={deleteByID}>Delete</button>
                </div>
            )
        }
    }
}

export default Employee;
