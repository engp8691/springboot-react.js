import React from 'react';
import Employee from './Employee';

const Employees = (props) => {
    const allEmployees = props.data;

    if (!allEmployees) {
        return null;
    }

    console.log(allEmployees);

    return (<div>
        {
            allEmployees.map(emp => {
                return (<Employee key={emp.id} id={emp.id} firstName={emp.firstName} lastName={emp.lastName} deleteEmployee={props.deleteEmployee} />);
            })
        }
    </div>);

}

export default Employees;
