import React from 'react';

const Error = ()=>{
    return (
        <div>Error Happened</div>
    )
}

export default Error;
