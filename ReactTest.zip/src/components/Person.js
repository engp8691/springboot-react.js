import React from 'react';

import "../App.css";

const Person = (props) => {

    return (<div className={"Person"}>
        <p>"Name:" + {props.name}</p>
        <p>"Age:" + {props.age}</p>

        <button data-testid={props.name} onClick={e=>props.dismissPeople(props.name)}>
            Delete
        </button>

    </div>);
}

export default Person;
