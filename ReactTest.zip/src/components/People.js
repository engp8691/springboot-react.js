import React from 'react';
import Person from './Person';

const People = (props) => {
    const [allPeople, setAllPeople] = React.useState([]);

    React.useEffect(() => {
        setAllPeople([
            {
                name: "Jeo Brown",
                age: 65
            },
            {
                name: "Roger Anderson",
                age: 25
            },
            {
                name: "Donald John Trump",
                age: 70
            },
            {
                name: "Barack Hussein Obama II",
                age: 58
            }           
        ]
        );
    }, []);

    const arrayRemove = (arr, value) =>{
        return arr.filter(function(ele){
            return ele.name !== value;
        });     
     }

    const dismissPeople = (name) => {
        const newPeople = arrayRemove(allPeople, name);
        console.log(newPeople);
        setAllPeople(newPeople);

        return null;
    }

    return (<div>
        {
            allPeople ? allPeople.map(person => {
                return (<Person key={person.name} name={person.name} age={person.age} dismissPeople={dismissPeople} />);
            }) : null
        }
    </div>);

}

export default People;
