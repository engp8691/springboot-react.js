To run it:

npm install
npm test -- --coverage
npm start

To run it with the RESTApi micro-sevices. Use mysql, and change the db connection details in the file of 

application.properties
And the DB schema file  and data file are also there.
To change to Oracle or other DB, do the same.

The Spring Boot2 application is in the zip file of SpringBoot2CRUD_20191211.zip.
Please use Eclipse to open the spring project. Or import it as Maven project.
please run it with 

spring-framework-5.1.6.RELEASE-dist.zip
hibernate-validator-6.1.0.Final-dist.zip
and the mysql connector JDBC driver




